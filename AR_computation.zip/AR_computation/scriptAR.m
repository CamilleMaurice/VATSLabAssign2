close all
clear all
clc

Extract_Blob
Compute_AR