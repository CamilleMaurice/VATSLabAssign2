Usage : launch scriptAR-m script through Matlab.
It will extract the blob and compute their aspect ratio according to what is specified into Extract_Blob.m

Extract_Blob specifies the input_folder containing the mask images, and the name format of the images to read.
