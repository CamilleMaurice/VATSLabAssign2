close all
clear all
clc

out_blob_directory ='./Output_blobs';

dir = sprintf('cd ''%s''',pwd);
blob_path = sprintf('cd %s/',out_blob_directory);
eval(blob_path);
[sts,number_blobs] = system('ls -1 | wc -l');
eval (dir);

aspect_ratio=[];

%go through the extracted blobs
%compute ans store their aspect ratio
for j = 1:str2num(number_blobs)   
    name_blob = sprintf('%s/blob%.4d.png',out_blob_directory,j);
    blob = imread(name_blob);
    aspect_ratio(1,j) = size(blob,2)/size(blob,1);      
               
end

%Display
m_aspect_ratio = mean(aspect_ratio)
std_aspect_ratio = std(aspect_ratio) 


%PLOT PDF
%x = [-2:.1:5];
%norm = normpdf(x,1.8537,0.6112);
%norm = normpdf(x,1.8537,0.1112);
%norm2 = normpdf(x,0.3645,0.3645);

%figure;
%plot(x,norm,x,norm2)
%legend('Gaussian classifier for cars','Gaussian classifier for person')
    