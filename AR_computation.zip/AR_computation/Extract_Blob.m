close all
clear all
clc

%Input Dataset train folder
DB_train = './binaryDB';
%DB_train = './cars';

%Create Output folder
mkdir Output_blobs;
blob_directory = './Output_blobs';

num_blobs = 0;
   
dir = sprintf('cd ''%s''',pwd);
directory_img = sprintf('cd %s/',DB_train);  
eval(directory_img)
[sts,number_img] = system('ls -1 | wc -l');   
nb = str2num(number_img);
eval (dir) 


for j=0:nb-3 
         
    name_mask = sprintf('%s/boundary%d.bmp',DB_train,j);
    %name_mask = sprintf('%s/carsgraz_%.3d.mask.0.png',video_dir,j)
        
    %read the mask 
    mask = imread(name_mask);
    %binarize if necessary
    %mask(mask>0) = 255;
 
    %extract largest component
    CC = bwconncomp(mask);  
    numPixels = cellfun(@numel,CC.PixelIdxList);
    [biggest,idx] = max(numPixels);
    S = regionprops(CC,'BoundingBox');
                
    y1 = round(S(idx,1).BoundingBox(1,1));
    x1 = round(S(idx,1).BoundingBox(1,2));
    y2 = round(y1+S(idx,1).BoundingBox(1,3));
    x2 = round(x1+S(idx,1).BoundingBox(1,4));
                     
    if x1 <= 0
       x1 = 1;
     end
    if y1 <= 0
        y1 = 1;
    end
    if x2 > size(mask,1)
        x2 = size(mask,1);
    end
    if y2 > size(mask,2)
        y2 = size(mask,2);
    end
 
    %resize
    crop_image = mask(x1:x2,y1:y2); 

    num_blobs = num_blobs+1;
    template_name = sprintf('%s/blob%.4d.png',blob_directory,num_blobs);
    imwrite(crop_image,template_name)
    
end        
